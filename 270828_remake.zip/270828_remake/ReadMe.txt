Here is a new code. I changed code. This time it should be accepted.
1) About base 8 instead of 16, it's my fault. Apologize, i was not attention.
2)About int and size_t. Probably, your professor was right, but 
firstly, I used C++(not C) and secondly, it is recommended to use unsigned
types with bit manipulations(link on GitHub ES.101)
https://github.com/isocpp/CppCoreGuidelines/blob/master/CppCoreGuidelines.md#arithmetic.
The new code is written with int instead of size_t.
